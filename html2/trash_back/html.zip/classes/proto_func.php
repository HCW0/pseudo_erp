<?php

    class proto_func{

        public $var1, $var2;

        function print(){

            print_r($this);

        }

    }

?>