  <?php
       session_start();

            $local_depth_position = $_GET['local_depth_position'];
            echo $local_depth_position;
           
            if(isset($_SESSION['depth_position_offset'])){
		
		               $_SESSION['depth_position_offset']++;

          	};
        

             header('location: ./su_script_user_personal_detail_interface.php');

    ?>

